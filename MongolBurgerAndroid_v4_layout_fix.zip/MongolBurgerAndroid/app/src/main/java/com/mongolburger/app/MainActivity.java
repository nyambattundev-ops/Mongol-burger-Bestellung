package com.mongolburger.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.os.Build;
import android.view.WindowInsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);

        // Android 15 / targetSdk 35 uses edge-to-edge. Put the whole WebView
        // inside the system-bar safe area instead of padding it. This is important
        // because the HTML uses 100vh; padding alone does not reduce that viewport.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) webView.getLayoutParams();
                lp.leftMargin = bars.left;
                lp.topMargin = bars.top;
                lp.rightMargin = bars.right;
                lp.bottomMargin = bars.bottom;
                webView.setLayoutParams(lp);
                return insets;
            });
        }
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        handleIntent(getIntent());
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("tmprintassistant".equalsIgnoreCase(scheme)) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(i);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "TM Print Assistant nicht installiert", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        if ("mongolburger".equalsIgnoreCase(scheme)) {
            handlePrintResult(uri);
            return true;
        }
        return false;
    }

    private void handleIntent(Intent intent) {
        if (intent != null && intent.getData() != null && "mongolburger".equalsIgnoreCase(intent.getData().getScheme())) {
            handlePrintResult(intent.getData());
        }
    }

    private void handlePrintResult(Uri uri) {
        String status = uri.getQueryParameter("status");
        if ("success".equalsIgnoreCase(status)) {
            Toast.makeText(this, "An Küche gedruckt ✓", Toast.LENGTH_SHORT).show();
        } else if ("error".equalsIgnoreCase(status)) {
            Toast.makeText(this, "Druckfehler – TM Print Assistant prüfen", Toast.LENGTH_LONG).show();
        }
        webView.loadUrl("javascript:window.scrollTo(0,0)");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
